﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace connection3
{
    class Program
    {
        static void Main(string[] args)
        {
            DataSet dataSet = new DataSet();  // 声明并初始化DataSet
            //SqlDataAdapter dataAdapter;　　 // 声明DataAdapter

            string constr = "server=localhost;User Id=root;password=88888888;Database=kadou";
            MySqlConnection mycon = new MySqlConnection(constr);
            mycon.Open();
            //以下是增加操作
            MySqlCommand mycmd = new MySqlCommand("insert into user(user_id,user_name) values('15301152','tiance')", mycon);
            //以下是删除操作
            //MySqlCommand mycmd = new MySqlCommand("DELETE FROM `kadou`.`user` WHERE (`user_id` = '15301152')", mycon);
            //以下是修改操作
            //MySqlCommand mycmd = new MySqlCommand("UPDATE `kadou`.`user` SET `user_id` = '15301160', `user_name` = 'wen' WHERE (`user_id` = '15301152')", mycon);
            //以下是查询操作
            /*MySqlCommand mycmd = new MySqlCommand("SELECT * FROM kadou.user", mycon);
            MySqlDataReader reader = mycmd.ExecuteReader();

            while (reader.Read())
            {
                Console.WriteLine("\t{0}\t{1}",
                    reader[0], reader[1]);
              
            }
            reader.Close();
            */
            if (mycmd.ExecuteNonQuery() > 0)
            {
                Console.WriteLine("数据插入成功！");
            }
            Console.ReadLine();
            mycon.Close();
        }

        private static string toString(MySqlConnection mycon)
        {
            throw new NotImplementedException();
        }
    }
}
